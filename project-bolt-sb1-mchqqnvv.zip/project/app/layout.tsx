import './globals.css';
import type { Metadata } from 'next';
import { Providers } from './providers';

export const metadata: Metadata = {
  title: 'Ghibli AI Art Generator',
  description: 'Generate beautiful Studio Ghibli-style artwork using AI',
  keywords: ['Studio Ghibli', 'AI Art', 'Anime Art Generator', 'Digital Art'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen bg-background font-sans antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}