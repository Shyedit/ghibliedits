"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/components/auth-provider";

interface Image {
  id: string;
  url: string;
  prompt: string;
  createdAt: string;
}

export default function GalleryPage() {
  const [images, setImages] = useState<Image[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    // TODO: Implement actual image fetching
    const mockImages: Image[] = [
      {
        id: "1",
        url: "https://images.unsplash.com/photo-1475274047050-1d0c0975c63e",
        prompt: "A peaceful Japanese village under a golden sunset",
        createdAt: new Date().toISOString(),
      },
      {
        id: "2",
        url: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b",
        prompt: "Rolling green hills with a magical creature",
        createdAt: new Date().toISOString(),
      },
    ];

    setImages(mockImages);
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <div className="container py-8">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <Card>
        <CardHeader>
          <CardTitle>Your Gallery</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {images.map((image) => (
              <div key={image.id} className="space-y-2">
                <img
                  src={image.url}
                  alt={image.prompt}
                  className="w-full h-48 object-cover rounded-lg"
                />
                <p className="text-sm text-muted-foreground">{image.prompt}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}