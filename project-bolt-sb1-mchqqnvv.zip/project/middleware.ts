import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const authPages = ["/login"];
  const protectedPages = ["/generate", "/gallery"];
  const path = request.nextUrl.pathname;

  // Get auth token from cookie
  const token = request.cookies.get("auth-token");

  // Redirect authenticated users away from auth pages
  if (authPages.includes(path) && token) {
    return NextResponse.redirect(new URL("/generate", request.url));
  }

  // Redirect unauthenticated users to login from protected pages
  if (protectedPages.includes(path) && !token) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/login", "/generate", "/gallery"],
};