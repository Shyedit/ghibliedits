exports.id=115,exports.ids=[115],exports.modules={4460:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});var l=r(2125);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,l.Z)("Chrome",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["line",{x1:"21.17",x2:"12",y1:"8",y2:"8",key:"a0cw5f"}],["line",{x1:"3.95",x2:"8.54",y1:"6.06",y2:"14",key:"1kftof"}],["line",{x1:"10.88",x2:"15.46",y1:"21.94",y2:"14",key:"1ymyh8"}]])},7114:(e,t,r)=>{e.exports=r(2778)},3618:(e,t,r)=>{"use strict";r.d(t,{f:()=>o});var l=r(9885),s=r(3979),y=r(80),a=l.forwardRef((e,t)=>(0,y.jsx)(s.WV.label,{...e,ref:t,onMouseDown:t=>{let r=t.target;r.closest("button, input, select, textarea")||(e.onMouseDown?.(t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));a.displayName="Label";var o=a}};